# NotchShade

Version 1.3 adds a custom macOS app icon. Automatic strip height still includes the extra 1 point added in version 1.2. Additional height options are relative to this Automatic baseline. Includes the version 1.1 fix that keeps the overlay at the top edge instead of below the menu bar.

A small native Mac menu bar app that blends a camera notch into a black strip across the top of the display. It does not disable or physically cover the camera.

## Install

1. Move NotchShade.app to Applications.
2. Open it. Look for the rectangle icon in the menu bar (there is no Dock icon).
3. Use the icon to toggle the strip or adjust its height. Settings persist between launches.
4. Optional: add the app under System Settings → General → Login Items & Extensions → Open at Login.

The included build is for Apple Silicon, macOS 13 or newer. It is locally signed, not Apple-notarized. If macOS blocks opening it, use System Settings → Privacy & Security → Open Anyway for this app after reviewing its source.

## Wallpaper apps

The app draws a separate black window rather than editing your wallpaper. Ordinary live wallpaper windows sit underneath it, so wallpaper changes should not remove the strip. No Accessibility, camera, or screen-recording access is requested. There is no network code, polling timer, or wallpaper replacement.

Compatibility with Wallpaper Machine / Wallpaper Engine and physical notched displays has not been verified in this development session. Wallpaper apps using unusually high window levels may cover the strip. System menus, menu-bar transparency, menu-text contrast, fullscreen transitions, and the lock screen remain controlled by macOS. In particular, macOS may composite its menu-bar material above the strip; this cannot guarantee a perfectly opaque black system menu bar under every appearance setting. Dark appearance may improve text contrast. The app does not change system appearance settings.

Notched displays are selected automatically using macOS safe-area information. For other displays or a manual preview, enable “Include displays without a notch.” Display connections, resolution changes, waking, and switching Spaces trigger a refresh. Quit removes all overlays immediately. To uninstall, quit and delete the app, and remove its login entry if you added one.

## Rebuild

With Apple Command Line Tools installed, run `bash Source/build.sh` from this folder. Source is included for inspection and customization.
