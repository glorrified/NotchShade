#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
notchshade_stage=$(mktemp -d /private/tmp/notchshade-build.XXXXXX)
trap 'rm -rf "$notchshade_stage"' EXIT
ditto --norsrc NotchShade.app "$notchshade_stage/NotchShade.app"
mkdir -p "$notchshade_stage/NotchShade.app/Contents/MacOS"
xcrun swiftc -O -target arm64-apple-macosx13.0 -module-cache-path /tmp/notchshade-module-cache -framework AppKit Source/main.swift -o "$notchshade_stage/NotchShade.app/Contents/MacOS/NotchShade"
xattr -cr "$notchshade_stage/NotchShade.app"
codesign --force --sign - "$notchshade_stage/NotchShade.app"
codesign --verify --strict "$notchshade_stage/NotchShade.app"
ditto --norsrc "$notchshade_stage/NotchShade.app" NotchShade.app
